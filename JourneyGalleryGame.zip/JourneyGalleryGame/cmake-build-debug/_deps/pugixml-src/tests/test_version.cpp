#include "../src/pugixml.hpp"

#if PUGIXML_VERSION != 1100
#error Unexpected pugixml version
#endif
