#pragma once

#include <SFML/Graphics.hpp>
#include <iostream>
#include <string>

class GameAssets {
public:
    GameAssets();

    sf::Texture wallUndig;
    sf::Texture wallDig;


};