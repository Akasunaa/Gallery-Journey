#include "myMain.h"

int main()
{
	return myMain();
}